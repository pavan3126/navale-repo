package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootFlightApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootFlightApplication.class, args);
	}

}
